"""Cyrberus Head - scanner daemon.

Watches for USB storage, admits or rejects it, scans it, and on a clean
result writes a signed manifest. Publishes its state for the kiosk UI.

Runs unprivileged as the `cyrberus` account. The only privileged operations
are mount and umount, granted narrowly through sudoers.

    python3 head/daemon.py                 run against real hardware
    python3 head/daemon.py --simulate      walk the states with no hardware
"""
import argparse
import logging
import os
import random
import signal
import sys
import time
from datetime import datetime, timedelta, timezone

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
for _d in ("common", "head"):
    sys.path.insert(0, os.path.join(_ROOT, _d))

import manifest_lib as M          # noqa: E402
import devices                     # noqa: E402
import mounts                      # noqa: E402
import scanner                     # noqa: E402
import state                       # noqa: E402

HEAD_ID = os.environ.get("CYRBERUS_HEAD_ID", "head-01")
KEY_DIR = os.environ.get("CYRBERUS_KEY_DIR", "/opt/cyrberus/keys")
PRIV_KEY = os.path.join(KEY_DIR, "head_private.pem")
PUB_KEY = os.path.join(KEY_DIR, "head_public.pem")
MOUNTPOINT = os.environ.get("CYRBERUS_MOUNT", "/mnt/cyrberus-scan")
VALIDITY_HOURS = int(os.environ.get("CYRBERUS_VALIDITY_HOURS", "12"))
def _default_log_path():
    """Prefer the system log directory; fall back when run by hand."""
    system = "/var/log/cyrberus"
    if os.path.isdir(system) and os.access(system, os.W_OK):
        return os.path.join(system, "head.log")
    runtime = os.environ.get("XDG_RUNTIME_DIR")
    if runtime and os.path.isdir(runtime):
        return os.path.join(runtime, "cyrberus", "head.log")
    import tempfile
    return os.path.join(tempfile.gettempdir(), "cyrberus-head.log")


LOG_PATH = os.environ.get("CYRBERUS_LOG") or _default_log_path()

# While idle, how often to re-check the virus-list version. After a boot clamd
# needs a minute or more to load signatures; this is how the operator screen
# moves from "not ready yet" to a version number without a drive cycle.
IDLE_SECONDS = 15


def _default_lock_path():
    if os.path.isdir("/run/lock"):
        return "/run/lock/cyrberus-head.lock"
    import tempfile
    return os.path.join(tempfile.gettempdir(), "cyrberus-head.lock")


LOCK_PATH = os.environ.get("CYRBERUS_LOCK") or _default_lock_path()

log = logging.getLogger("cyrberus.head")


class AlreadyRunning(Exception):
    pass


def single_instance(path=None):
    """Hold an exclusive lock for this process's lifetime.

    Two Head daemons would both receive every udev event, race to mount the
    same drive on the same mountpoint, and overwrite each other's state. The
    usual way that happens: the boot service is running and someone starts a
    second copy by hand over SSH. Returns the open descriptor (keep it alive);
    raises AlreadyRunning if another daemon holds the lock.
    """
    import fcntl
    path = path or LOCK_PATH
    try:
        # Open without O_CREAT first: with fs.protected_regular, O_CREAT on a
        # file another account created in sticky /run/lock is refused.
        fd = os.open(path, os.O_RDONLY)
    except FileNotFoundError:
        fd = os.open(path, os.O_RDONLY | os.O_CREAT, 0o644)
    try:
        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        os.close(fd)
        raise AlreadyRunning(path)
    return fd


def setup_logging(verbose=False):
    log.setLevel(logging.DEBUG if verbose else logging.INFO)
    fmt = logging.Formatter("%(asctime)s %(levelname)-7s %(message)s")
    sh = logging.StreamHandler(sys.stdout)
    sh.setFormatter(fmt)
    log.addHandler(sh)
    try:
        os.makedirs(os.path.dirname(LOG_PATH), exist_ok=True)
        fh = logging.FileHandler(LOG_PATH)
        fh.setFormatter(fmt)
        log.addHandler(fh)
    except OSError as e:
        log.warning("file logging unavailable (%s); console only", e)


def reference_code():
    """Short code shown on the threat screen.

    The operator reads this to IT, who finds the full detection detail in the
    log. The malware family name would mean nothing to a front-office user.
    """
    return "H%d-%04d" % (random.randint(1, 9), random.randint(1000, 9999))


class Head:
    def __init__(self, simulate=False):
        self.simulate = simulate
        self.busy = False
        self.sig_version = None

    # -- state publishing -------------------------------------------------
    def ready(self):
        self.sig_version = self._sig_date()
        state.publish(state.READY, signatures_updated=self.sig_version)
        log.info("ready (virus list %s)", self.sig_version or "not loaded yet")

    def idle(self):
        """Housekeeping between devices. Only touches the screen when it is
        showing READY, so a result screen is never overwritten."""
        if state.current() != state.READY:
            return
        version = self._sig_date()
        if version != self.sig_version:
            self.sig_version = version
            state.publish(state.READY, signatures_updated=version)
            log.info("virus list now %s", version or "unavailable")

    def working(self, phase, **kw):
        state.publish(state.WORKING, phase=phase, **kw)

    def blocked(self, reason, **kw):
        state.publish(state.BLOCKED, reason=reason, **kw)
        log.warning("blocked: %s", reason)

    def threat(self, code, detections, **kw):
        state.publish(state.THREAT, reference=code,
                      detection_count=len(detections), **kw)
        for path, sig in detections:
            log.error("DETECTION ref=%s sig=%s path=%s", code, sig, path)

    def clean(self, manifest, **kw):
        state.publish(state.CLEAN,
                      expires_at=manifest["expires_at"],
                      file_count=len(manifest["files"]), **kw)
        log.info("validated: %d files, expires %s",
                 len(manifest["files"]), manifest["expires_at"])

    def _sig_date(self):
        info = scanner.engine_info()
        return info.get("signature_version", "")

    # -- the pipeline -----------------------------------------------------
    def handle(self, record):
        label = record.get("model") or record.get("node", "device")
        size = devices.human_size(record.get("size_bytes", 0))
        log.info("device attached: %s (%s) %s", label, size, record.get("node"))

        self.working("identifying", model=label, size=size)

        ok, reason = devices.admit(record)
        if not ok:
            self.blocked(reason, model=label)
            return

        part = record["partitions"][0]
        fstype = (part.get("fstype") or "").lower()

        try:
            mounts.mount_ro(part["node"], MOUNTPOINT, fstype)
        except mounts.MountError as e:
            log.error("mount failed: %s", e)
            self.blocked("This drive could not be opened for checking.", model=label)
            return

        try:
            self._inspect(record, part, fstype, label, size)
        finally:
            mounts.sync()
            try:
                mounts.unmount(MOUNTPOINT)
            except mounts.MountError as e:
                log.error("unmount failed: %s", e)

    def _inspect(self, record, part, fstype, label, size):
        self.working("scanning", model=label, size=size)
        t0 = time.time()
        result = scanner.scan_tree(MOUNTPOINT)
        scan_seconds = round(time.time() - t0, 1)
        log.info("scan finished in %ss: %r", scan_seconds, result)

        # Order matters: a real detection is reported as a threat even if the
        # scan also hit errors - the operator must see the red screen and IT
        # must get the DETECTION log line.
        if result.malware:
            self.threat(reference_code(), result.malware, model=label)
            return

        if result.engine_error:
            log.error("scanner unavailable: %s", result.engine_error)
            self.blocked("The checking service is not available right now.",
                         model=label)
            return

        if result.limited:
            # Too large, too deeply nested, or encrypted: ClamAV could not see
            # inside. Fail closed, but do not tell the user it is malware.
            for path, sig in result.limited[:10]:
                log.warning("not fully inspected: %s (%s)", path, sig)
            self.blocked("Some files on this drive are too large or locked "
                         "to be checked.", model=label)
            return

        if result.errors:
            # Files the engine could not inspect are not evidence of safety.
            for path, msg in result.errors[:10]:
                log.warning("unscannable: %s (%s)", path, msg)
            self.blocked("Some files on this drive could not be checked.",
                         model=label)
            return

        if not result.clean:
            # Exit status said "found" but nothing was parsed. Unknown is not
            # safe: fail closed.
            log.error("scanner reported a finding that could not be parsed")
            self.blocked("This drive could not be checked.", model=label)
            return

        # Clean. Hash everything for the manifest, reporting progress.
        total_hint = len(M.enumerate_files(MOUNTPOINT))
        self.working("hashing", model=label, size=size, done=0, total=total_hint)

        last = [0.0]

        def progress(done, total):
            now = time.time()
            if now - last[0] > 0.2 or done == total:
                last[0] = now
                self.working("hashing", model=label, size=size,
                             done=done, total=total)

        entries, problems = M.walk_payload(MOUNTPOINT, on_progress=progress)
        if problems:
            kind, where = problems[0]
            log.warning("undescribable entry (%s): %s", kind, where)
            self.blocked("This drive contains something we cannot record.",
                         model=label)
            return

        self.working("signing", model=label, size=size)
        manifest = self._sign(record, entries, scan_seconds, fstype, part["node"])
        if manifest is None:
            self.blocked("The approval could not be written to this drive.",
                         model=label)
            return
        self.clean(manifest, model=label)

    def _sign(self, record, entries, scan_seconds, fstype, part_node):
        from cryptography.hazmat.primitives import serialization

        try:
            with open(PRIV_KEY, "rb") as f:
                priv = serialization.load_pem_private_key(f.read(), password=None)
            with open(PUB_KEY, "rb") as f:
                kid = M.key_id(f.read())
        except OSError as e:
            log.error("cannot load signing key: %s", e)
            return None

        info = scanner.engine_info()
        now = datetime.now(timezone.utc).replace(microsecond=0)
        manifest = M.build_manifest(
            HEAD_ID, kid, now, now + timedelta(hours=VALIDITY_HOURS),
            devices.device_block(record),
            {
                "engine": info["engine"],
                "engine_version": info["engine_version"],
                "signature_version": info["signature_version"],
                "files_scanned": len(entries),
                "bytes_scanned": sum(e["size"] for e in entries),
                "duration_seconds": scan_seconds,
            },
            entries)

        blob = M.serialize(manifest)
        sig = priv.sign(blob)
        outdir = os.path.join(MOUNTPOINT, M.MANIFEST_DIR)

        try:
            # Unmount the read-only scan mount, then mount fresh read-write
            # for exactly as long as the manifest write takes.
            mounts.unmount(MOUNTPOINT)
            mounts.mount_rw(part_node, MOUNTPOINT, fstype)
            os.makedirs(outdir, exist_ok=True)
            with open(os.path.join(outdir, M.MANIFEST_NAME), "wb") as f:
                f.write(blob)
                f.flush()
                os.fsync(f.fileno())
            with open(os.path.join(outdir, M.SIG_NAME), "wb") as f:
                f.write(M.encode_sig(sig))
                f.flush()
                os.fsync(f.fileno())
            mounts.sync()
        except (OSError, mounts.MountError) as e:
            log.error("writing manifest failed: %s", e)
            return None
        finally:
            # Drop the writable mount immediately, whatever happened above.
            try:
                mounts.unmount(MOUNTPOINT)
            except mounts.MountError as e:
                log.error("could not release writable mount: %s", e)
        return manifest

    # -- loops ------------------------------------------------------------
    def run(self):
        log.info("Cyrberus Head starting (head_id=%s, validity=%dh)",
                 HEAD_ID, VALIDITY_HOURS)
        log.info("state file: %s", state.STATE_PATH)
        try:
            mounts.unmount(MOUNTPOINT)      # clear anything left by a crash
        except mounts.MountError:
            pass
        self.ready()
        state.start_heartbeat()

        # A drive attached before we were listening (plugged in during boot,
        # or mid-scan when the service restarted) produced its udev event
        # already. Never pick it up silently - ask for a deliberate re-insert.
        try:
            present = devices.current_usb_disks()
        except Exception as e:
            log.warning("could not list attached drives: %s", e)
            present = []
        if present:
            log.info("drive already attached at startup: %s",
                     ", ".join(r.get("node") or "?" for r in present))
            self.blocked(devices.R_PRESENT_AT_START,
                         model=present[0].get("model") or "")

        for action, record in devices.monitor(idle_every=IDLE_SECONDS):
            if action == "idle":
                self.idle()
            elif action == "add":
                if record.get("in_use"):
                    # The system's own disk (USB-booted Pi), re-announced by
                    # e.g. `udevadm trigger`. Not a drive to check.
                    log.info("ignoring %s: in use by this system", record.get("node"))
                    continue
                if self.busy:
                    log.warning("device attached while busy; ignoring")
                    continue
                self.busy = True
                try:
                    self.handle(record)
                except Exception:
                    log.exception("unhandled error while processing device")
                    self.blocked("Something went wrong while checking this drive.")
                finally:
                    self.busy = False
            elif action == "remove":
                log.info("device removed: %s", record.get("node"))
                try:
                    mounts.unmount(MOUNTPOINT)
                except mounts.MountError:
                    pass
                self.ready()

    def run_simulation(self):
        """Walk every screen with no hardware. For UI work and demos."""
        log.info("simulation mode - no hardware will be touched")
        log.info("state file: %s", state.STATE_PATH)
        log.info("point the UI at it with:  python3 ui/kiosk.py --windowed")
        state.start_heartbeat()
        demo = [
            (state.READY, 3, {}),
            (state.WORKING, 2, {"phase": "identifying", "model": "SanDisk Ultra", "size": "32 GB"}),
            (state.WORKING, 4, {"phase": "scanning", "model": "SanDisk Ultra", "size": "32 GB"}),
            ("_hashing", 4, {}),
            (state.WORKING, 1.5, {"phase": "signing", "model": "SanDisk Ultra", "size": "32 GB"}),
            (state.CLEAN, 6, {"expires_at": (datetime.now(timezone.utc) + timedelta(hours=12))
                              .strftime("%Y-%m-%dT%H:%M:%SZ"), "file_count": 2061}),
            (state.READY, 3, {}),
            (state.WORKING, 3, {"phase": "scanning", "model": "Kingston DT", "size": "16 GB"}),
            (state.THREAT, 7, {"reference": reference_code(), "detection_count": 2}),
            (state.READY, 3, {}),
            (state.BLOCKED, 6, {"reason": devices.R_MULTI_PARTITION, "model": "Generic USB"}),
            (state.READY, 3, {}),
            (state.BLOCKED, 6, {"reason": devices.R_ENCRYPTED, "model": "IronKey"}),
        ]
        while True:
            for name, hold, kw in demo:
                if name == "_hashing":
                    total, steps = 2061, 28
                    for i in range(steps + 1):
                        state.publish(state.WORKING, phase="hashing",
                                      model="SanDisk Ultra", size="32 GB",
                                      done=int(total * i / steps), total=total)
                        time.sleep(hold / steps)
                    continue
                state.publish(name, **kw)
                log.info("simulate: %s %s", name, kw.get("phase", ""))
                time.sleep(hold)


def main():
    ap = argparse.ArgumentParser(description="Cyrberus Head scanner daemon")
    ap.add_argument("--simulate", action="store_true",
                    help="cycle through the operator screens with no hardware")
    ap.add_argument("-v", "--verbose", action="store_true")
    args = ap.parse_args()

    setup_logging(args.verbose)

    try:
        lock = single_instance()        # noqa: F841 - held until exit
    except AlreadyRunning:
        log.error("another Head daemon is already running (lock %s).", LOCK_PATH)
        log.error("If the boot service is on, stop it first:  "
                  "sudo systemctl stop cyrberus-scanner")
        sys.exit(1)
    except OSError as e:
        # The lock is a safety net, not a requirement - carry on without it.
        log.warning("could not take the single-instance lock (%s); continuing", e)

    # systemd stops services with SIGTERM. Turn it into a normal exit so the
    # cleanup below runs and a drive is never left mounted.
    signal.signal(signal.SIGTERM, lambda signum, frame: sys.exit(0))

    head = Head(simulate=args.simulate)
    try:
        if args.simulate:
            head.run_simulation()
        else:
            head.run()
    except KeyboardInterrupt:
        pass
    finally:
        log.info("stopping")
        if not args.simulate:
            try:
                mounts.unmount(MOUNTPOINT)
            except mounts.MountError:
                pass


if __name__ == "__main__":
    main()
